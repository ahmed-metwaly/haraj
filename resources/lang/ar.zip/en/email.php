<?php
/**
 * Created by PhpStorm.
 * User: maste
 * Date: 8/17/2016
 * Time: 11:50 PM
 */

return [
    'activeTitle' => 'Activation your email',
    'activeSubject' => 'Activation your email',
];