<?php
/**
 * Created by PhpStorm.
 * User: maste
 * Date: 8/17/2016
 * Time: 11:59 PM
 */

return [
    'addAdminOk' => 'Admin has been added successfully, please check your e-mail added now.',
    'addAdminNo' => 'Sorry have not been added try again.',
    'editAdminOk1' => 'Admin has been edited successfully, please check your e-mail edited now.',
    'editAdminOk0' => 'Admin has been edited successfully',
    'editAdminNo' => 'Sorry have not been edited try again.',
    'deletedOk' => 'Has been deleted successfully.',
    'deletedNo' => 'Sorry have not been deleted try again.',
    'loginFalse' => 'Error in email or password.',
    'loginRequired' => 'You must be logged in to perform this operation',
    'activeOk' => 'E-mail was activated successfully',
    'activeNo' => 'An error in the activation must click on the activation link sent to the email',
    'fPasswordError' => 'This email have not registered',
    'forgetTitle' => 'Forget password',
    'updateTrue' => 'Edited successfully',
    'updateFalse' => 'The amendment did not try again',
];