<?php


return [
    'loginPageTitle' => 'Admin Login',
    'loginEmail' => 'E-Mail Address',
    'loginPassword' => 'Password',
    'loginForget' => 'Forgot password?',
    'loginSubmit' => 'Sign in',

];